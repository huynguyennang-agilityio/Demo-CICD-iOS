fastlane documentation
----

# Installation

Make sure you have the latest version of the Xcode command line tools installed:

```sh
xcode-select --install
```

For _fastlane_ installation instructions, see [Installing _fastlane_](https://docs.fastlane.tools/#installing-fastlane)

# Available Actions

## iOS

### ios sync_dev_certs

```sh
[bundle exec] fastlane ios sync_dev_certs
```

Sync Development certificates

### ios sync_adhoc_certs

```sh
[bundle exec] fastlane ios sync_adhoc_certs
```

Sync Ad Hoc certificates

### ios create_certs

```sh
[bundle exec] fastlane ios create_certs
```

Tạo mới hoặc regenerate certificates (chỉ chạy khi cần)

### ios build_dev

```sh
[bundle exec] fastlane ios build_dev
```

Build Development (chạy trên device)

### ios build_adhoc

```sh
[bundle exec] fastlane ios build_adhoc
```

Build Ad Hoc (distribute nội bộ)

### ios test

```sh
[bundle exec] fastlane ios test
```

Run unit tests

----

This README.md is auto-generated and will be re-generated every time [_fastlane_](https://fastlane.tools) is run.

More information about _fastlane_ can be found on [fastlane.tools](https://fastlane.tools).

The documentation of _fastlane_ can be found on [docs.fastlane.tools](https://docs.fastlane.tools).
